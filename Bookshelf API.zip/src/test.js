// // const arr = {'kurni':'hai', 'lita':'Aku kangen', 'sukma':'miawmiaw'};
// // const { kurni, lita, sukma, abdul } = arr;

// if(!abdul){
//   console.log("hai");
//   return;
// }
// console.log("yes");

if(5 === 5){
  console.log("hai");
}else{
  console.log("object");
}

